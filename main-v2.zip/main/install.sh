#!/usr/bin/env bash

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$HOME/.dotfiles-backup/$(date +%Y%m%d_%H%M%S)"

echo "=============================="
echo "  Hack the Clown Dotfiles    "
echo "  Installer for Arch Linux   "
echo "=============================="
echo ""

# ------------------------------
# Helper functions
# ------------------------------

backup_file() {
    local file="$1"
    if [ -f "$file" ] || [ -d "$file" ]; then
        mkdir -p "$BACKUP_DIR"
        local rel_path="${file#$HOME/}"
        mkdir -p "$BACKUP_DIR/$(dirname "$rel_path")"
        mv "$file" "$BACKUP_DIR/$rel_path"
        echo "  Backed up: $file"
    fi
}

symlink_config() {
    local src="$1"
    local dst="$2"
    mkdir -p "$(dirname "$dst")"
    backup_file "$dst"
    ln -sf "$src" "$dst"
    echo "  Linked: $dst -> $src"
}

install_package() {
    local pkg="$1"
    if ! pacman -Qi "$pkg" &>/dev/null; then
        echo "  Installing $pkg..."
        sudo pacman -S --noconfirm "$pkg"
    else
        echo "  $pkg already installed, skipping."
    fi
}

install_aur_package() {
    local pkg="$1"
    if ! pacman -Qi "$pkg" &>/dev/null; then
        if command -v yay &>/dev/null; then
            echo "  Installing $pkg (AUR)..."
            yay -S --noconfirm "$pkg"
        elif command -v paru &>/dev/null; then
            echo "  Installing $pkg (AUR)..."
            paru -S --noconfirm "$pkg"
        else
            echo "  WARNING: No AUR helper found. Install yay or paru first, then install $pkg manually."
            return 1
        fi
    else
        echo "  $pkg already installed, skipping."
    fi
}

# ------------------------------
# Check for AUR helper
# ------------------------------
echo "[1/7] Checking for AUR helper..."
if ! command -v yay &>/dev/null && ! command -v paru &>/dev/null; then
    echo "  No AUR helper found. Installing yay..."
    sudo pacman -S --noconfirm git base-devel
    git clone https://aur.archlinux.org/yay-bin.git /tmp/yay-bin
    (cd /tmp/yay-bin && makepkg -si --noconfirm)
    rm -rf /tmp/yay-bin
    echo "  yay installed."
fi

# ------------------------------
# Install system packages
# ------------------------------
echo ""
echo "[2/7] Installing system packages..."

PACKAGES=(
    i3-wm
    i3lock
    i3status
    polybar
    rofi
    picom
    feh
    dex
    xsettingsd
    terminator
    zsh
    neovim
    fzf
    git
    base-devel
    noto-fonts
    ttf-roboto
    ttf-fira-code
    xorg-xrandr
    xorg-xsetroot
    xorg-xprop
    xorg-xkill
    lightdm
    lightdm-webkit2-greeter
)

for pkg in "${PACKAGES[@]}"; do
    install_package "$pkg"
done

# ------------------------------
# Install AUR packages (fonts)
# ------------------------------
echo ""
echo "[3/7] Installing fonts from AUR..."

AUR_PACKAGES=(
    ttf-martianmono-nerd-font
    nerd-fonts-noto-sans-mono
)

for pkg in "${AUR_PACKAGES[@]}"; do
    install_aur_package "$pkg" || true
done

# Refresh font cache
echo "  Refreshing font cache..."
fc-cache -fv

# ------------------------------
# Install Oh My Zsh
# ------------------------------
echo ""
echo "[4/7] Installing Oh My Zsh..."
if [ ! -d "$HOME/.oh-my-zsh" ]; then
    sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
    echo "  Oh My Zsh installed."
else
    echo "  Oh My Zsh already installed, skipping."
fi

# ------------------------------
# Install Zsh plugins
# ------------------------------
echo ""
echo "[5/7] Installing Zsh plugins..."

# Powerlevel10k
if [ ! -d "${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k" ]; then
    git clone --depth=1 https://github.com/romkatv/powerlevel10k.git \
        "${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}/themes/powerlevel10k"
    echo "  Powerlevel10k installed."
else
    echo "  Powerlevel10k already installed, skipping."
fi

# zsh-autosuggestions
if [ ! -d "${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions" ]; then
    git clone https://github.com/zsh-users/zsh-autosuggestions \
        "${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions"
    echo "  zsh-autosuggestions installed."
else
    echo "  zsh-autosuggestions already installed, skipping."
fi

# zsh-syntax-highlighting
if [ ! -d "${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting" ]; then
    git clone https://github.com/zsh-users/zsh-syntax-highlighting \
        "${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting"
    echo "  zsh-syntax-highlighting installed."
else
    echo "  zsh-syntax-highlighting already installed, skipping."
fi

# ------------------------------
# Install Atuin
# ------------------------------
echo ""
echo "[6/7] Installing Atuin..."
if ! command -v atuin &>/dev/null; then
    curl --proto '=https' --tlsv1.2 -sSf https://setup.atuin.sh | bash
    echo "  Atuin installed."
else
    echo "  Atuin already installed, skipping."
fi

# ------------------------------
# Deploy dotfiles
# ------------------------------
echo ""
echo "[7/7] Deploying dotfiles..."

# Copy wallpaper
mkdir -p "$HOME/Pictures"
backup_file "$HOME/Pictures/wallpaper.jpg"
cp "$SCRIPT_DIR/wallpaper.jpg" "$HOME/Pictures/wallpaper.jpg"
echo "  Copied wallpaper.jpg to ~/Pictures/"

# Symlink configs
symlink_config "$SCRIPT_DIR/.zshrc" "$HOME/.zshrc"
symlink_config "$SCRIPT_DIR/.p10k.zsh" "$HOME/.p10k.zsh"
symlink_config "$SCRIPT_DIR/.config/i3/config" "$HOME/.config/i3/config"
symlink_config "$SCRIPT_DIR/.config/polybar/polybar.ini" "$HOME/.config/polybar/polybar.ini"
symlink_config "$SCRIPT_DIR/.config/polybar/polybar_launch.sh" "$HOME/.config/polybar/polybar_launch.sh"
symlink_config "$SCRIPT_DIR/.config/picom/picom.conf" "$HOME/.config/picom/picom.conf"
symlink_config "$SCRIPT_DIR/.config/rofi/rofi.rasi" "$HOME/.config/rofi/rofi.rasi"
symlink_config "$SCRIPT_DIR/.config/rofi/themes/dark.rasi" "$HOME/.config/rofi/themes/dark.rasi"
symlink_config "$SCRIPT_DIR/.config/terminator/config" "$HOME/.config/terminator/config"
symlink_config "$SCRIPT_DIR/.config/atuin/config.toml" "$HOME/.config/atuin/config.toml"
symlink_config "$SCRIPT_DIR/.config/atuin/themes/clown-theme.toml" "$HOME/.config/atuin/themes/clown-theme.toml"
symlink_config "$SCRIPT_DIR/.config/nvim/init.lua" "$HOME/.config/nvim/init.lua"
symlink_config "$SCRIPT_DIR/.config/nvim/lua/plugins/myplugins.lua" "$HOME/.config/nvim/lua/plugins/myplugins.lua"
symlink_config "$SCRIPT_DIR/.config/xsettingsd/xsettingsd.conf" "$HOME/.config/xsettingsd/xsettingsd.conf"
symlink_config "$SCRIPT_DIR/.config/gtk-3.0/settings.ini" "$HOME/.config/gtk-3.0/settings.ini"

# LightDM webkit greeter theme
symlink_config "$SCRIPT_DIR/.config/lightdm/webkit2-greeter.conf" "$HOME/.config/lightdm/webkit2-greeter.conf"
symlink_config "$SCRIPT_DIR/.config/lightdm/webkit2-theme-clown" "$HOME/.config/lightdm/webkit2-theme-clown"

# Configure LightDM greeter session
echo ""
echo "Configuring LightDM..."
sudo sed -i 's/^greeter-session=.*/greeter-session=lightdm-webkit2-greeter/' /etc/lightdm/lightdm.conf 2>/dev/null || \
    echo "greeter-session=lightdm-webkit2-greeter" | sudo tee -a /etc/lightdm/lightdm.conf > /dev/null
echo "  Greeter session set to lightdm-webkit2-greeter."

# Enable LightDM
sudo systemctl enable lightdm
sudo systemctl set-default graphical.target
echo "  LightDM enabled as default display manager."

# Make polybar launch script executable
chmod +x "$SCRIPT_DIR/.config/polybar/polybar_launch.sh"

# Set zsh as default shell
echo ""
echo "Setting zsh as default shell..."
if [ "$SHELL" != "$(which zsh)" ]; then
    chsh -s "$(which zsh)"
    echo "  Default shell changed to zsh."
else
    echo "  zsh is already the default shell."
fi

# ------------------------------
# Done
# ------------------------------
echo ""
echo "=============================="
echo "  Installation Complete!      "
echo "=============================="
echo ""
echo "Backups of old configs saved to: $BACKUP_DIR"
echo ""
echo "Next steps:"
echo "  1. Reboot to start LightDM login screen"
echo "  2. Run 'p10k configure' to set up your Powerlevel10k theme"
echo "  3. Press Super+Shift+R to restart i3 after logging in"
echo ""
echo "Keybindings:"
echo "  Super+Return         Terminal (terminator)"
echo "  Super+Shift+D        App launcher (rofi)"
echo "  Super+Shift+R        Restart i3"
echo "  Super+Shift+E        Exit i3"
echo "  Super+Shift+L        Lock screen"
echo ""
