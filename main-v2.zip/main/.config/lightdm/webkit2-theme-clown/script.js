let authSession = null;
let selectedSession = null;

function updateClock() {
    const now = new Date();
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    document.getElementById('clock').textContent = h + ':' + m;

    const days = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    const months = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
    document.getElementById('date').textContent =
        days[now.getDay()] + ', ' + months[now.getMonth()] + ' ' + now.getDate();
}

function setSession(name) {
    selectedSession = name;
    document.querySelectorAll('.session-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-session="' + name + '"]').classList.add('active');
}

function doLogin() {
    const user = document.getElementById('username').value.trim();
    const pass = document.getElementById('password').value;
    const errEl = document.getElementById('error');

    if (!user) {
        errEl.textContent = 'Enter username';
        return;
    }

    errEl.textContent = '';

    lightdm.cancel_authentication();
    authSession = lightdm.start_authentication(user);
}

function on Authentication complete(result) {
    if (result === 'success') {
        if (selectedSession) {
            lightdm.login(lightdm.authentication_user, selectedSession);
        } else {
            lightdm.login(lightdm.authentication_user, lightdm.default_session);
        }
    } else {
        document.getElementById('error').textContent = 'Authentication failed';
        document.getElementById('password').value = '';
    }
}

function showPrompt(text, type) {
    document.getElementById('password').focus();
}

function showError(text) {
    document.getElementById('error').textContent = text;
}

function onReset() {
    document.getElementById('password').value = '';
    document.getElementById('error').textContent = '';
}

function powerShutdown() {
    lightdm.shutdown();
}

function powerReboot() {
    lightdm.reboot();
}

function powerSuspend() {
    lightdm.suspend();
}

document.addEventListener('DOMContentLoaded', function () {
    updateClock();
    setInterval(updateClock, 1000);

    if (typeof lightdm !== 'undefined') {
        const users = lightdm.users;
        if (users && users.length > 0) {
            document.getElementById('username').value = users[0].name;
        }

        const sessions = lightdm.sessions;
        const sessionContainer = document.getElementById('sessions');
        if (sessions && sessions.length > 0) {
            sessions.forEach(function (s, i) {
                const btn = document.createElement('button');
                btn.className = 'session-btn' + (i === 0 ? ' active' : '');
                btn.setAttribute('data-session', s.key);
                btn.textContent = s.name;
                btn.onclick = function () { setSession(s.key); };
                sessionContainer.appendChild(btn);
            });
            selectedSession = sessions[0].key;
        }

        document.getElementById('password').addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                doLogin();
            }
        });

        document.getElementById('login-btn').addEventListener('click', doLogin);
    }
});
